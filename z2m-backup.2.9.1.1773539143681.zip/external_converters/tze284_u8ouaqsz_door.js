// tze284_u8ouaqsz_door.js
const exposes = require('zigbee-herdsman-converters/lib/exposes');
const tuya = require('zigbee-herdsman-converters/lib/tuya');
const e = exposes.presets;
const ea = exposes.access;

const definition = {
  zigbeeModel: ['TS0601'],
  model: 'TS0601',
  vendor: '_TZE284_u8ouaqsz',
  description: 'Door sensor with siren alarm',
  fromZigbee: [tuya.fz.datapoints],
  toZigbee: [tuya.tz.datapoints],
  configure: tuya.configureMagicPacket,
  exposes: [
    e.contact(),
    e.battery(),
    e.binary('alarm', ea.STATE_SET, 'ON', 'OFF').withDescription('Sound the alarm'),
    e.binary('strobe', ea.STATE_SET, 'ON', 'OFF').withDescription('Flash LED while alarming'),
    e.numeric('volume', ea.STATE_SET).withValueMin(1).withValueMax(100).withValueStep(1)
      .withUnit('%').withDescription('Alarm volume'),
    e.numeric('duration', ea.STATE_SET).withValueMin(3).withValueMax(180).withValueStep(1)
      .withUnit('s').withDescription('Alarm duration'),
  ],
  meta: {
    // Adjust these DP IDs if your logs show different numbers (see step 4).
    tuyaDatapoints: [
      [1, 'contact', tuya.valueConverter.trueFalseInvert], // contact open/closed
      [2, 'battery', tuya.valueConverter.raw],             // battery (raw % or level)
      [101, 'alarm', tuya.valueConverter.onOff],           // sounder on/off
      [102, 'strobe', tuya.valueConverter.onOff],          // led flash
      [103, 'volume', tuya.valueConverter.raw],            // 1..100
      [104, 'duration', tuya.valueConverter.raw],          // seconds
    ],
  },
};

module.exports = definition;
